<?php

	//FCM Notification
    $fcmServerKey = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
    $fcmNotificationTopic = 'blogger_wallpaper_app_topic';

	//OneSignal Notification
    $oneSignalAppId = 'xxxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxxx';
    $oneSignalRestApiKey = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';

?>